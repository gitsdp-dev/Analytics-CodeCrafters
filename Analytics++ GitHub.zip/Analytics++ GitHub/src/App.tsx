import { useState, useMemo } from 'react';
import FileUpload from './components/FileUpload';
import DataTable from './components/DataTable';
import ChartBuilder from './components/ChartBuilder';
import StatCards from './components/StatCards';
import Calculator from './components/Calculator';
import { ParsedData, computeColumnStats, parseFile } from './utils/dataParser';
import {
  BarChart2, Table, Calculator as CalcIcon, TrendingUp,
  Database, ChevronDown, RefreshCw, X, Menu, Home,
  Upload, Info
} from 'lucide-react';

type Tab = 'overview' | 'charts' | 'table' | 'calculator';

const TABS: { id: Tab; label: string; icon: any; mobileLabel: string }[] = [
  { id: 'overview', label: 'Overview', mobileLabel: 'Overview', icon: TrendingUp },
  { id: 'charts', label: 'Charts', mobileLabel: 'Charts', icon: BarChart2 },
  { id: 'table', label: 'Data Table', mobileLabel: 'Table', icon: Table },
  { id: 'calculator', label: 'Calculator', mobileLabel: 'Calc', icon: CalcIcon },
];

function MetricCard({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color: string }) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-gradient-to-br ${color} p-4 space-y-1`}>
      <p className="text-white/50 text-xs font-medium uppercase tracking-wider">{label}</p>
      <p className="text-white text-2xl sm:text-3xl font-bold font-mono">{value}</p>
      {sub && <p className="text-white/40 text-xs">{sub}</p>}
    </div>
  );
}

// ─── Welcome Screen ──────────────────────────────────────────────────────────
function WelcomeScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="min-h-screen bg-[#0a0a14] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-violet-600/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-cyan-600/8 rounded-full blur-[80px]" />
        <div className="absolute top-1/2 left-0 w-[300px] h-[300px] bg-pink-600/5 rounded-full blur-[60px]" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }}
        />
      </div>
      <div className="relative z-10 w-full max-w-2xl text-center space-y-8">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-3 mb-2">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center shadow-2xl shadow-violet-500/30">
              <Database className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                Analyze
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">++</span>
              </h1>
              <p className="text-white/40 text-sm font-medium">Powerful Analytics Visual Calculator</p>
            </div>
          </div>
          <p className="text-white/60 text-base sm:text-lg max-w-lg mx-auto leading-relaxed">
            Import your databases and spreadsheets. Instantly visualize, analyze, and calculate insights from your data.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {[
            '📊 8+ Chart Types', '🗃️ Excel & Access DB',
            '📐 Formula Calculator', '📈 Statistical Analysis',
            '📋 14+ File Formats', '📱 Mobile Optimized',
          ].map(f => (
            <span key={f} className="px-3 py-1.5 rounded-full bg-white/8 border border-white/10 text-white/60 text-sm">{f}</span>
          ))}
        </div>
        <button
          onClick={onStart}
          className="group inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-violet-500 to-cyan-500 text-white font-bold text-lg shadow-2xl shadow-violet-500/30 hover:shadow-violet-500/50 hover:scale-105 transition-all duration-300"
        >
          <Upload className="w-5 h-5 group-hover:scale-110 transition-transform" />
          Import Your Data
        </button>
        <p className="text-white/20 text-xs">
          Supports .xlsx · .xls · .xlsm · .xlsb · .ods · .accdb · .mdb · .dbf · .csv · .tsv · .json · .dif · .slk and more
        </p>
      </div>
    </div>
  );
}

// ─── Upload Screen ────────────────────────────────────────────────────────────
function UploadScreen({ onBack, onDataLoaded }: {
  onBack: () => void;
  onDataLoaded: (d: ParsedData, f: File) => void;
}) {
  return (
    <div className="min-h-screen bg-[#0a0a14] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-violet-600/10 rounded-full blur-[100px]" />
      </div>
      <div className="relative z-10 w-full max-w-2xl space-y-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all">
            <X className="w-5 h-5 text-white/60" />
          </button>
          <div>
            <h2 className="text-white font-bold text-xl">Import Data</h2>
            <p className="text-white/40 text-sm">Upload any supported database or spreadsheet file</p>
          </div>
        </div>
        <FileUpload onDataLoaded={onDataLoaded} />
      </div>
    </div>
  );
}

// ─── Import Modal ─────────────────────────────────────────────────────────────
function ImportModal({ onClose, onDataLoaded }: {
  onClose: () => void;
  onDataLoaded: (d: ParsedData, f: File) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
      <div className="bg-[#0f0f20] border border-white/15 rounded-3xl p-5 w-full max-w-lg space-y-5 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-bold text-lg">Import New File</h3>
          <button onClick={onClose} className="p-2 rounded-xl bg-white/5 hover:bg-white/10">
            <X className="w-5 h-5 text-white/60" />
          </button>
        </div>
        <FileUpload onDataLoaded={onDataLoaded} />
      </div>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
function Dashboard({ data, onReset, onImport }: {
  data: ParsedData;
  onReset: () => void;
  onImport: () => void;
}) {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [activeSheet, setActiveSheet] = useState<string>(data.activeSheet || '');
  const [currentData, setCurrentData] = useState<ParsedData>(data);
  const [currentFile, _setCurrentFile] = useState<File | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const stats = useMemo(() => computeColumnStats(currentData.headers, currentData.rows), [currentData]);
  const numericStats = stats.filter(s => s.type === 'numeric' || s.type === 'mixed');

  const handleSheetChange = async (sheet: string) => {
    if (!currentFile) return;
    try {
      const newData = await parseFile(currentFile, sheet);
      setCurrentData(newData);
      setActiveSheet(sheet);
    } catch (e) {
      console.error(e);
    }
  };

  const displayData = currentData;

  return (
    <div className="min-h-screen bg-[#0a0a14] flex flex-col">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[500px] h-[300px] bg-violet-600/5 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[300px] bg-cyan-600/5 rounded-full blur-[60px]" />
      </div>

      {/* Header */}
      <header className="relative z-20 border-b border-white/8 bg-[#0a0a14]/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
              <Database className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-black text-lg tracking-tight hidden sm:block">
              Analyze<span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-cyan-400">++</span>
            </span>
          </div>

          <div className="flex-1 min-w-0 mx-3">
            <div className="flex items-center gap-2">
              <span className="text-white/80 text-sm font-medium truncate">{displayData.fileName}</span>
              {displayData.sheets && displayData.sheets.length > 1 && (
                <div className="relative hidden sm:block">
                  <select
                    value={activeSheet}
                    onChange={e => handleSheetChange(e.target.value)}
                    className="appearance-none bg-white/10 border border-white/10 rounded-lg pl-2.5 pr-6 py-1 text-white/70 text-xs focus:outline-none focus:border-violet-400/50 cursor-pointer"
                  >
                    {displayData.sheets.map(s => (
                      <option key={s} value={s} className="bg-gray-900">{s}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-white/40 pointer-events-none" />
                </div>
              )}
            </div>
            <p className="text-white/30 text-xs">
              {displayData.rowCount.toLocaleString()} rows · {displayData.colCount} cols · {displayData.fileType}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onImport}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/8 hover:bg-white/15 border border-white/10 text-white/70 text-xs transition-all"
            >
              <Upload className="w-3.5 h-3.5" />
              Import
            </button>
            <button
              onClick={onReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-red-500/20 border border-white/10 hover:border-red-500/30 text-white/50 hover:text-red-400 text-xs transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(v => !v)}
              className="sm:hidden p-2 rounded-xl bg-white/5 border border-white/10 text-white/60"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </div>

        {displayData.sheets && displayData.sheets.length > 1 && (
          <div className="sm:hidden px-4 pb-2">
            <select
              value={activeSheet}
              onChange={e => handleSheetChange(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-white/70 text-sm focus:outline-none"
            >
              {displayData.sheets.map(s => (
                <option key={s} value={s} className="bg-gray-900">{s}</option>
              ))}
            </select>
          </div>
        )}

        {mobileMenuOpen && (
          <div className="sm:hidden absolute top-full left-0 right-0 bg-[#0f0f20]/95 backdrop-blur-xl border-b border-white/10 z-30 p-3 space-y-1">
            <button
              onClick={() => { onImport(); setMobileMenuOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-white/8 text-white/70 text-sm transition-all"
            >
              <Upload className="w-4 h-4" />
              Import New File
            </button>
            <button
              onClick={() => { onReset(); setMobileMenuOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-red-500/10 text-red-400/70 text-sm transition-all"
            >
              <Home className="w-4 h-4" />
              Back to Home
            </button>
          </div>
        )}
      </header>

      {/* Desktop Tab Bar */}
      <div className="hidden sm:block relative z-10 border-b border-white/8 bg-[#0a0a14]/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1">
            {TABS.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'border-violet-400 text-white'
                      : 'border-transparent text-white/40 hover:text-white/70 hover:border-white/20'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 relative z-10 max-w-7xl mx-auto w-full px-4 py-5 pb-24 sm:pb-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-white font-bold text-lg mb-1">Dataset Overview</h2>
              <p className="text-white/40 text-sm">Statistical summary of your imported data</p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <MetricCard label="Total Rows" value={displayData.rowCount.toLocaleString()} sub="records" color="from-violet-600/20 to-violet-600/5" />
              <MetricCard label="Columns" value={displayData.colCount} sub="fields" color="from-cyan-600/20 to-cyan-600/5" />
              <MetricCard label="Numeric Cols" value={numericStats.length} sub="quantitative" color="from-emerald-600/20 to-emerald-600/5" />
              <MetricCard label="File Format" value={displayData.fileType || '—'} sub={displayData.activeSheet ? `Sheet: ${displayData.activeSheet}` : 'imported'} color="from-amber-600/20 to-amber-600/5" />
            </div>
            {stats.length > 0 && (
              <div>
                <h3 className="text-white/60 text-sm font-semibold mb-3 uppercase tracking-wider">Column Statistics</h3>
                <StatCards stats={stats} />
              </div>
            )}
            <div className="flex items-start gap-3 p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
              <Info className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="text-violet-300 font-medium">Ready for Analysis</p>
                <p className="text-white/40 mt-0.5">
                  Use <strong className="text-white/60">Charts</strong> to visualize, <strong className="text-white/60">Table</strong> to explore, and <strong className="text-white/60">Calculator</strong> for custom formulas.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'charts' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-white font-bold text-lg mb-1">Chart Builder</h2>
              <p className="text-white/40 text-sm">Visualize your data with interactive charts</p>
            </div>
            <ChartBuilder data={displayData} />
          </div>
        )}

        {activeTab === 'table' && (
          <div className="space-y-4 flex flex-col" style={{ height: 'calc(100vh - 200px)' }}>
            <div>
              <h2 className="text-white font-bold text-lg mb-1">Data Explorer</h2>
              <p className="text-white/40 text-sm">Browse, search, and sort your data</p>
            </div>
            <div className="flex-1 min-h-0">
              <DataTable data={displayData} />
            </div>
          </div>
        )}

        {activeTab === 'calculator' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-white font-bold text-lg mb-1">Analytics Calculator</h2>
              <p className="text-white/40 text-sm">Run statistical formulas on your data columns</p>
            </div>
            <Calculator data={displayData} />
          </div>
        )}
      </main>

      {/* Mobile Bottom Tab Bar */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-20 bg-[#0f0f1a]/95 backdrop-blur-xl border-t border-white/10">
        <div className="flex">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex flex-col items-center gap-1 py-3 px-1 transition-all duration-200 ${
                  activeTab === tab.id ? 'text-violet-400' : 'text-white/30'
                }`}
              >
                <div className={`p-1.5 rounded-xl transition-all ${activeTab === tab.id ? 'bg-violet-500/20' : ''}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-medium">{tab.mobileLabel}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Suppress unused warning */}
      <span className="hidden">{currentFile?.name}</span>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
type Screen = 'welcome' | 'upload' | 'dashboard';

export default function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [data, setData] = useState<ParsedData | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);

  const handleDataLoaded = (d: ParsedData, _f: File) => {
    setData(d);
    setScreen('dashboard');
    setShowImportModal(false);
  };

  const handleReset = () => {
    setData(null);
    setScreen('welcome');
  };

  if (screen === 'welcome') {
    return <WelcomeScreen onStart={() => setScreen('upload')} />;
  }

  if (screen === 'upload') {
    return (
      <UploadScreen
        onBack={() => setScreen('welcome')}
        onDataLoaded={handleDataLoaded}
      />
    );
  }

  if (screen === 'dashboard' && data) {
    return (
      <>
        <Dashboard
          data={data}
          onReset={handleReset}
          onImport={() => setShowImportModal(true)}
        />
        {showImportModal && (
          <ImportModal
            onClose={() => setShowImportModal(false)}
            onDataLoaded={handleDataLoaded}
          />
        )}
      </>
    );
  }

  return <WelcomeScreen onStart={() => setScreen('upload')} />;
}
