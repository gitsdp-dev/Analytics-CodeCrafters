import React, { useCallback, useState } from 'react';
import { Upload, FileSpreadsheet, Database, FileText, X, CheckCircle2, AlertCircle, ChevronDown } from 'lucide-react';
import { parseFile, ParsedData } from '../utils/dataParser';

interface FileUploadProps {
  onDataLoaded: (data: ParsedData, file: File) => void;
}

const SUPPORTED_FORMATS = [
  { ext: '.xlsx', label: 'Excel 2007+', category: 'spreadsheet' },
  { ext: '.xls', label: 'Excel 97-2003', category: 'spreadsheet' },
  { ext: '.xlsm', label: 'Excel Macro', category: 'spreadsheet' },
  { ext: '.xlsb', label: 'Excel Binary', category: 'spreadsheet' },
  { ext: '.ods', label: 'OpenDocument', category: 'spreadsheet' },
  { ext: '.csv', label: 'CSV', category: 'text' },
  { ext: '.tsv', label: 'TSV', category: 'text' },
  { ext: '.json', label: 'JSON', category: 'text' },
  { ext: '.accdb', label: 'Access DB', category: 'database' },
  { ext: '.mdb', label: 'Access 97-2003', category: 'database' },
  { ext: '.dbf', label: 'dBase', category: 'database' },
  { ext: '.dif', label: 'DIF', category: 'other' },
  { ext: '.slk', label: 'SYLK', category: 'other' },
  { ext: '.prn', label: 'Lotus', category: 'other' },
];

const FileIcon = ({ type }: { type: string }) => {
  if (type === 'spreadsheet') return <FileSpreadsheet className="w-5 h-5 text-emerald-400" />;
  if (type === 'database') return <Database className="w-5 h-5 text-blue-400" />;
  return <FileText className="w-5 h-5 text-purple-400" />;
};

export default function FileUpload({ onDataLoaded }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showFormats, setShowFormats] = useState(false);

  const handleFile = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const data = await parseFile(file);
      setSuccess(`Loaded "${file.name}" — ${data.rowCount.toLocaleString()} rows × ${data.colCount} columns`);
      onDataLoaded(data, file);
    } catch (err: any) {
      setError(err.message || 'Failed to parse file');
    } finally {
      setIsLoading(false);
    }
  }, [onDataLoaded]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = '';
  };

  return (
    <div className="w-full space-y-4">
      {/* Drop Zone */}
      <label
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        className={`
          relative flex flex-col items-center justify-center w-full
          min-h-[180px] sm:min-h-[220px] rounded-2xl border-2 border-dashed cursor-pointer
          transition-all duration-300 group
          ${isDragging
            ? 'border-violet-400 bg-violet-500/10 scale-[1.01]'
            : 'border-white/20 bg-white/5 hover:border-violet-400/60 hover:bg-white/10'
          }
        `}
      >
        <input
          type="file"
          className="hidden"
          onChange={onInputChange}
          accept=".xlsx,.xls,.xlsm,.xlsb,.xlt,.xltx,.ods,.csv,.tsv,.txt,.json,.accdb,.mdb,.dbf,.dif,.slk,.sylk,.prn,.eth"
        />
        <div className="flex flex-col items-center gap-3 p-6 text-center">
          <div className={`
            w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-300
            ${isDragging ? 'bg-violet-500/30 scale-110' : 'bg-white/10 group-hover:bg-violet-500/20 group-hover:scale-105'}
          `}>
            {isLoading ? (
              <div className="w-8 h-8 border-2 border-violet-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Upload className={`w-8 h-8 transition-colors ${isDragging ? 'text-violet-300' : 'text-white/60 group-hover:text-violet-300'}`} />
            )}
          </div>
          <div>
            <p className="text-white font-semibold text-base sm:text-lg">
              {isLoading ? 'Processing file...' : isDragging ? 'Drop your file here' : 'Drop file or click to browse'}
            </p>
            <p className="text-white/40 text-sm mt-1">
              Supports Excel, CSV, JSON, Access DB, dBase & more
            </p>
          </div>
        </div>
      </label>

      {/* Status Messages */}
      {error && (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-red-500/15 border border-red-500/30">
          <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 shrink-0" />
          <p className="text-red-300 text-sm">{error}</p>
          <button onClick={() => setError(null)} className="ml-auto shrink-0"><X className="w-4 h-4 text-red-400" /></button>
        </div>
      )}
      {success && (
        <div className="flex items-start gap-3 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
          <p className="text-emerald-300 text-sm">{success}</p>
          <button onClick={() => setSuccess(null)} className="ml-auto shrink-0"><X className="w-4 h-4 text-emerald-400" /></button>
        </div>
      )}

      {/* Supported Formats */}
      <button
        onClick={() => setShowFormats(v => !v)}
        className="flex items-center gap-2 text-white/50 hover:text-white/80 text-sm transition-colors mx-auto"
      >
        <span>Supported file formats</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${showFormats ? 'rotate-180' : ''}`} />
      </button>

      {showFormats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {SUPPORTED_FORMATS.map(f => (
            <div key={f.ext} className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2 border border-white/10">
              <FileIcon type={f.category} />
              <div>
                <p className="text-white/80 text-xs font-mono font-semibold">{f.ext}</p>
                <p className="text-white/40 text-xs">{f.label}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
