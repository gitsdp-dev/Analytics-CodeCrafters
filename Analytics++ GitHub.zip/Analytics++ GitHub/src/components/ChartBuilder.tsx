import { useState, useMemo } from 'react';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { ParsedData, getChartData, getFrequencyData, getScatterData, getHistogramData, detectColumnType } from '../utils/dataParser';
import { BarChart2, LineChart as LineIcon, PieChart as PieIcon, Minus, Activity, Target } from 'lucide-react';

type ChartType = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'scatter' | 'histogram';
type AggType = 'sum' | 'avg' | 'count' | 'min' | 'max';

const CHART_TYPES: { id: ChartType; label: string; icon: any }[] = [
  { id: 'bar', label: 'Bar', icon: BarChart2 },
  { id: 'line', label: 'Line', icon: LineIcon },
  { id: 'area', label: 'Area', icon: Activity },
  { id: 'pie', label: 'Pie', icon: PieIcon },
  { id: 'donut', label: 'Donut', icon: Target },
  { id: 'scatter', label: 'Scatter', icon: Minus },
  { id: 'histogram', label: 'Histogram', icon: BarChart2 },
];

const PALETTE = [
  '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444',
  '#ec4899', '#3b82f6', '#84cc16', '#f97316', '#a855f7',
  '#14b8a6', '#eab308', '#6366f1', '#d946ef', '#0ea5e9',
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900/95 border border-white/20 rounded-xl p-3 shadow-xl backdrop-blur-sm">
      <p className="text-white/60 text-xs mb-2">{label}</p>
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-white/70 text-xs">{p.name}:</span>
          <span className="text-white font-mono text-xs font-semibold">
            {typeof p.value === 'number' ? p.value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p.value}
          </span>
        </div>
      ))}
    </div>
  );
};

interface ChartBuilderProps {
  data: ParsedData;
}

type PlainData = { name: string; value: number };
type ScatterPoint = { x: number; y: number; label?: string };

export default function ChartBuilder({ data }: ChartBuilderProps) {
  const [chartType, setChartType] = useState<ChartType>('bar');
  const [xCol, setXCol] = useState<string>(data.headers[0] || '');
  const [yCol, setYCol] = useState<string>('');
  const [agg, setAgg] = useState<AggType>('sum');
  const [bins, setBins] = useState(20);

  const numericCols = useMemo(() =>
    data.headers.filter(h => {
      const vals = data.rows.map(r => r[h]);
      const t = detectColumnType(vals);
      return t === 'numeric' || t === 'mixed';
    }), [data]);

  const allCols = data.headers;
  const effectiveY = yCol || numericCols[0] || '';

  const plainData = useMemo((): PlainData[] => {
    if (chartType === 'histogram') {
      return getHistogramData(data.rows, effectiveY || numericCols[0] || allCols[0], bins);
    }
    if (chartType === 'pie' || chartType === 'donut') {
      if (effectiveY && xCol) return getChartData(data.rows, xCol, effectiveY, agg, 15);
      return getFrequencyData(data.rows, xCol, 15);
    }
    if (xCol && effectiveY) return getChartData(data.rows, xCol, effectiveY, agg, 50);
    return getFrequencyData(data.rows, xCol, 50);
  }, [chartType, xCol, effectiveY, agg, bins, data, numericCols, allCols]);

  const scatterData = useMemo((): ScatterPoint[] => {
    if (chartType !== 'scatter') return [];
    return getScatterData(data.rows, xCol, effectiveY);
  }, [chartType, xCol, effectiveY, data]);

  const axisStyle = {
    tick: { fill: 'rgba(255,255,255,0.4)', fontSize: 11 },
    axisLine: { stroke: 'rgba(255,255,255,0.1)' },
    tickLine: { stroke: 'rgba(255,255,255,0.1)' },
  };

  const h = 320;

  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <BarChart data={plainData} margin={{ top: 10, right: 10, left: 0, bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="name" {...axisStyle} angle={-35} textAnchor="end" interval="preserveStartEnd" />
              <YAxis {...axisStyle} width={55} tickFormatter={(v: number) => v >= 1000 ? `${(v / 1000).toFixed(1)}K` : String(v)} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {plainData.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        );
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <LineChart data={plainData} margin={{ top: 10, right: 10, left: 0, bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="name" {...axisStyle} angle={-35} textAnchor="end" interval="preserveStartEnd" />
              <YAxis {...axisStyle} width={55} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: '#8b5cf6' }} />
            </LineChart>
          </ResponsiveContainer>
        );
      case 'area':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <AreaChart data={plainData} margin={{ top: 10, right: 10, left: 0, bottom: 60 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="name" {...axisStyle} angle={-35} textAnchor="end" interval="preserveStartEnd" />
              <YAxis {...axisStyle} width={55} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} fill="url(#areaGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        );
      case 'pie':
      case 'donut':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <PieChart>
              <Pie
                data={plainData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={chartType === 'donut' ? 110 : 130}
                innerRadius={chartType === 'donut' ? 55 : 0}
                paddingAngle={2}
                label={({ name, percent }: any) =>
                  `${name ?? ''} (${(((percent as number) || 0) * 100).toFixed(1)}%)`
                }
                labelLine={{ stroke: 'rgba(255,255,255,0.3)' }}
              >
                {plainData.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend
                formatter={(val: string) => <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: 11 }}>{val}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
        );
      case 'scatter':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <ScatterChart margin={{ top: 10, right: 10, left: 0, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="x" name={xCol} {...axisStyle} />
              <YAxis dataKey="y" name={effectiveY} {...axisStyle} width={55} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomTooltip />} />
              <Scatter data={scatterData} fill="#8b5cf6" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        );
      case 'histogram':
        return (
          <ResponsiveContainer width="100%" height={h}>
            <BarChart data={plainData} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="name" {...axisStyle} />
              <YAxis {...axisStyle} width={45} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" fill="#06b6d4" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );
      default:
        return null;
    }
  };

  const hasData = chartType === 'scatter' ? scatterData.length > 0 : plainData.length > 0;

  return (
    <div className="space-y-4">
      {/* Chart Type Selector */}
      <div className="flex flex-wrap gap-2">
        {CHART_TYPES.map(ct => {
          const Icon = ct.icon;
          return (
            <button
              key={ct.id}
              onClick={() => setChartType(ct.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                chartType === ct.id
                  ? 'bg-violet-500 text-white shadow-lg shadow-violet-500/30'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {ct.label}
            </button>
          );
        })}
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {chartType !== 'histogram' && (
          <div className="space-y-1">
            <label className="text-white/40 text-xs font-medium">X Axis / Category</label>
            <select
              value={xCol}
              onChange={e => setXCol(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-violet-400/50 focus:bg-white/10 transition-all"
            >
              {allCols.map(c => <option key={c} value={c} className="bg-gray-900">{c}</option>)}
            </select>
          </div>
        )}

        {chartType !== 'pie' && chartType !== 'donut' && (
          <div className="space-y-1">
            <label className="text-white/40 text-xs font-medium">
              {chartType === 'histogram' ? 'Column' : 'Y Axis / Value'}
            </label>
            <select
              value={effectiveY}
              onChange={e => setYCol(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-violet-400/50 focus:bg-white/10 transition-all"
            >
              {numericCols.length > 0
                ? numericCols.map(c => <option key={c} value={c} className="bg-gray-900">{c}</option>)
                : allCols.map(c => <option key={c} value={c} className="bg-gray-900">{c}</option>)
              }
            </select>
          </div>
        )}

        {['bar', 'line', 'area', 'pie', 'donut'].includes(chartType) && effectiveY && (
          <div className="space-y-1">
            <label className="text-white/40 text-xs font-medium">Aggregation</label>
            <select
              value={agg}
              onChange={e => setAgg(e.target.value as AggType)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-violet-400/50 focus:bg-white/10 transition-all"
            >
              <option value="sum" className="bg-gray-900">Sum</option>
              <option value="avg" className="bg-gray-900">Average</option>
              <option value="count" className="bg-gray-900">Count</option>
              <option value="min" className="bg-gray-900">Min</option>
              <option value="max" className="bg-gray-900">Max</option>
            </select>
          </div>
        )}

        {chartType === 'histogram' && (
          <div className="space-y-1">
            <label className="text-white/40 text-xs font-medium">Bins: {bins}</label>
            <input
              type="range"
              min={5}
              max={100}
              value={bins}
              onChange={e => setBins(Number(e.target.value))}
              className="w-full accent-violet-500 mt-2"
            />
          </div>
        )}
      </div>

      {/* Chart */}
      <div className="bg-white/3 rounded-2xl border border-white/10 p-4">
        {hasData ? renderChart() : (
          <div className="h-64 flex items-center justify-center text-white/30 text-sm">
            Select valid columns to generate chart
          </div>
        )}
      </div>
    </div>
  );
}
