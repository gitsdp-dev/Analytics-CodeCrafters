import { ColumnStats, formatNumber } from '../utils/dataParser';
import { TrendingUp, Hash, AlignLeft, ToggleLeft, Calendar, Minus } from 'lucide-react';

interface StatCardsProps {
  stats: ColumnStats[];
}

const typeConfig = {
  numeric: { icon: TrendingUp, color: 'from-cyan-500 to-blue-500', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', text: 'text-cyan-300' },
  string: { icon: AlignLeft, color: 'from-purple-500 to-pink-500', bg: 'bg-purple-500/10', border: 'border-purple-500/20', text: 'text-purple-300' },
  boolean: { icon: ToggleLeft, color: 'from-amber-500 to-orange-500', bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-300' },
  date: { icon: Calendar, color: 'from-emerald-500 to-teal-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', text: 'text-emerald-300' },
  mixed: { icon: Hash, color: 'from-rose-500 to-red-500', bg: 'bg-rose-500/10', border: 'border-rose-500/20', text: 'text-rose-300' },
};

export default function StatCards({ stats }: StatCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      {stats.map(stat => {
        const cfg = typeConfig[stat.type];
        const Icon = cfg.icon;
        return (
          <div
            key={stat.name}
            className={`rounded-2xl border ${cfg.border} ${cfg.bg} p-4 space-y-3 hover:scale-[1.02] transition-transform duration-200`}
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className={`text-xs font-semibold uppercase tracking-wider ${cfg.text} mb-0.5`}>
                  {stat.type}
                </p>
                <p className="text-white font-semibold text-sm truncate" title={stat.name}>
                  {stat.name}
                </p>
              </div>
              <div className={`p-2 rounded-xl bg-gradient-to-br ${cfg.color} opacity-80 shrink-0`}>
                <Icon className="w-4 h-4 text-white" />
              </div>
            </div>

            {/* Stats */}
            {stat.type === 'numeric' || stat.type === 'mixed' ? (
              <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                {[
                  { label: 'Count', val: stat.count.toLocaleString() },
                  { label: 'Nulls', val: stat.nullCount.toLocaleString() },
                  { label: 'Mean', val: formatNumber(stat.mean) },
                  { label: 'Median', val: formatNumber(stat.median) },
                  { label: 'Min', val: formatNumber(stat.min as number) },
                  { label: 'Max', val: formatNumber(stat.max as number) },
                  { label: 'Sum', val: formatNumber(stat.sum) },
                  { label: 'Std Dev', val: formatNumber(stat.stdDev) },
                ].map(({ label, val }) => (
                  <div key={label}>
                    <p className="text-white/30 text-xs">{label}</p>
                    <p className="text-white/90 text-xs font-mono font-medium">{val}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-white/30 text-xs">Count</p>
                    <p className="text-white/90 text-xs font-mono">{stat.count.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-xs">Unique</p>
                    <p className="text-white/90 text-xs font-mono">{stat.uniqueCount.toLocaleString()}</p>
                  </div>
                </div>
                {stat.topValues && stat.topValues.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-white/30 text-xs">Top Values</p>
                    {stat.topValues.slice(0, 3).map(({ value, count }) => (
                      <div key={value} className="flex items-center gap-2">
                        <div className="flex-1 bg-white/10 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-full bg-gradient-to-r ${cfg.color} rounded-full`}
                            style={{ width: `${(count / stat.count) * 100}%` }}
                          />
                        </div>
                        <span className="text-white/60 text-xs font-mono w-8 text-right">{count}</span>
                        <span className="text-white/50 text-xs truncate max-w-[60px]" title={value}>{value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Null indicator */}
            {stat.nullCount > 0 && (
              <div className="flex items-center gap-1.5 text-xs text-amber-400/70">
                <Minus className="w-3 h-3" />
                <span>{((stat.nullCount / (stat.count + stat.nullCount)) * 100).toFixed(1)}% missing</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
