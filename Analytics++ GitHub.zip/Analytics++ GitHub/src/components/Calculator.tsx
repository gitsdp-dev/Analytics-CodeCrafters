import { useState, useMemo } from 'react';
import { ParsedData, computeColumnStats, formatNumber } from '../utils/dataParser';
import { Calculator as CalcIcon, Play, Trash2, Plus } from 'lucide-react';

interface CalculatorProps {
  data: ParsedData;
}

type FormulaResult = {
  id: number;
  label: string;
  formula: string;
  result: string | number;
  error?: string;
};

const QUICK_FORMULAS = [
  { label: 'Row Count', formula: 'COUNT()' },
  { label: 'Column Count', formula: 'COLS()' },
  { label: 'SUM of column', formula: 'SUM(col)' },
  { label: 'AVERAGE of column', formula: 'AVG(col)' },
  { label: 'MAX of column', formula: 'MAX(col)' },
  { label: 'MIN of column', formula: 'MIN(col)' },
  { label: 'STD DEV', formula: 'STDDEV(col)' },
  { label: 'MEDIAN', formula: 'MEDIAN(col)' },
  { label: 'UNIQUE COUNT', formula: 'UNIQUE(col)' },
  { label: 'NULL COUNT', formula: 'NULLS(col)' },
  { label: 'VARIANCE', formula: 'VARIANCE(col)' },
  { label: 'RANGE (max-min)', formula: 'RANGE(col)' },
];

function evaluateFormula(formula: string, data: ParsedData): string | number {
  const f = formula.trim().toUpperCase();

  // COUNT()
  if (f === 'COUNT()') return data.rowCount;
  if (f === 'COLS()') return data.colCount;

  // Match FUNC(column)
  const match = f.match(/^(\w+)\((.+)\)$/);
  if (!match) {
    // Try to eval as a math expression (safe subset)
    try {
      // Replace basic math only
      const sanitized = formula.replace(/[^0-9+\-*/().\s]/g, '');
      // eslint-disable-next-line no-new-func
      const result = Function('"use strict"; return (' + sanitized + ')')();
      return typeof result === 'number' ? parseFloat(result.toFixed(6)) : result;
    } catch {
      throw new Error('Unknown formula. Try SUM(ColumnName), AVG(ColumnName), etc.');
    }
  }

  const func = match[1];
  const colName = match[2];

  // Find column (case-insensitive)
  const actualCol = data.headers.find(h => h.toUpperCase() === colName) ||
    data.headers.find(h => h.toUpperCase().includes(colName));

  if (!actualCol) throw new Error(`Column "${colName}" not found`);

  const vals = data.rows.map(r => r[actualCol]);
  const nums = vals.map(v => Number(v)).filter(n => !isNaN(n));

  if (nums.length === 0 && !['UNIQUE', 'NULLS', 'COUNT'].includes(func)) {
    throw new Error(`Column "${actualCol}" has no numeric values`);
  }

  switch (func) {
    case 'SUM': return nums.reduce((a, b) => a + b, 0);
    case 'AVG':
    case 'MEAN': return nums.reduce((a, b) => a + b, 0) / nums.length;
    case 'MAX': return Math.max(...nums);
    case 'MIN': return Math.min(...nums);
    case 'COUNT': return vals.filter(v => v !== null && v !== undefined && v !== '').length;
    case 'UNIQUE': return new Set(vals.map(v => String(v))).size;
    case 'NULLS': return vals.filter(v => v === null || v === undefined || v === '').length;
    case 'STDDEV':
    case 'STD': {
      const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
      return Math.sqrt(nums.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / nums.length);
    }
    case 'VARIANCE': {
      const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
      return nums.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / nums.length;
    }
    case 'MEDIAN': {
      const sorted = [...nums].sort((a, b) => a - b);
      const mid = Math.floor(sorted.length / 2);
      return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
    }
    case 'RANGE': return Math.max(...nums) - Math.min(...nums);
    case 'PRODUCT': return nums.reduce((a, b) => a * b, 1);
    case 'PERCENTILE_25': {
      const sorted = [...nums].sort((a, b) => a - b);
      return sorted[Math.floor(sorted.length * 0.25)];
    }
    case 'PERCENTILE_75': {
      const sorted = [...nums].sort((a, b) => a - b);
      return sorted[Math.floor(sorted.length * 0.75)];
    }
    default:
      throw new Error(`Unknown function: ${func}`);
  }
}

let idCounter = 0;

export default function Calculator({ data }: CalculatorProps) {
  const [formula, setFormula] = useState('');
  const [label, setLabel] = useState('');
  const [results, setResults] = useState<FormulaResult[]>([]);

  const stats = useMemo(() => computeColumnStats(data.headers, data.rows), [data]);

  const runFormula = () => {
    if (!formula.trim()) return;
    try {
      const result = evaluateFormula(formula, data);
      const formatted = typeof result === 'number' ? parseFloat(result.toFixed(8)) : result;
      setResults(prev => [
        { id: ++idCounter, label: label || formula, formula, result: formatted },
        ...prev,
      ]);
      setFormula('');
      setLabel('');
    } catch (err: any) {
      setResults(prev => [
        { id: ++idCounter, label: label || formula, formula, result: '', error: err.message },
        ...prev,
      ]);
    }
  };

  const insertQuick = (f: string) => {
    setFormula(f.replace('col', data.headers[0] || 'Column'));
  };

  const removeResult = (id: number) => setResults(prev => prev.filter(r => r.id !== id));

  return (
    <div className="space-y-5">
      {/* Input Area */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
        <div className="flex items-center gap-2 text-white/60">
          <CalcIcon className="w-4 h-4" />
          <span className="text-sm font-medium">Formula Calculator</span>
        </div>

        <div className="space-y-2">
          <input
            type="text"
            placeholder="Label (optional)"
            value={label}
            onChange={e => setLabel(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder-white/30 text-sm focus:outline-none focus:border-violet-400/50 transition-all"
          />
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. SUM(Revenue), AVG(Price), 1024 * 1024"
              value={formula}
              onChange={e => setFormula(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && runFormula()}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder-white/30 text-sm font-mono focus:outline-none focus:border-violet-400/50 transition-all"
            />
            <button
              onClick={runFormula}
              className="flex items-center gap-1.5 px-4 py-2 bg-violet-500 hover:bg-violet-400 rounded-xl text-white text-sm font-medium transition-all shadow-lg shadow-violet-500/20"
            >
              <Play className="w-3.5 h-3.5" />
              Run
            </button>
          </div>
        </div>

        {/* Quick Formulas */}
        <div>
          <p className="text-white/30 text-xs mb-2">Quick Formulas</p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_FORMULAS.map(q => (
              <button
                key={q.formula}
                onClick={() => insertQuick(q.formula)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-violet-500/20 border border-white/10 hover:border-violet-400/30 text-white/60 hover:text-violet-300 text-xs transition-all"
              >
                <Plus className="w-2.5 h-2.5" />
                {q.label}
              </button>
            ))}
          </div>
        </div>

        {/* Function Reference */}
        <details className="group">
          <summary className="text-white/30 text-xs cursor-pointer hover:text-white/60 transition-colors list-none flex items-center gap-1">
            <span>▶</span> <span className="group-open:hidden">Show function reference</span>
            <span className="hidden group-open:inline">Hide function reference</span>
          </summary>
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {[
              ['COUNT()', 'Non-null count'],
              ['SUM(col)', 'Sum of values'],
              ['AVG(col)', 'Average'],
              ['MEDIAN(col)', 'Median'],
              ['MAX(col)', 'Maximum'],
              ['MIN(col)', 'Minimum'],
              ['STDDEV(col)', 'Std deviation'],
              ['VARIANCE(col)', 'Variance'],
              ['RANGE(col)', 'Max − Min'],
              ['UNIQUE(col)', 'Unique count'],
              ['NULLS(col)', 'Null count'],
              ['PRODUCT(col)', 'Product'],
            ].map(([fn, desc]) => (
              <button
                key={fn}
                onClick={() => setFormula(fn.replace('col', data.headers[0] || 'Col'))}
                className="text-left px-2 py-1.5 rounded-lg bg-white/3 hover:bg-white/8 border border-white/8 transition-all"
              >
                <p className="text-violet-400 text-xs font-mono">{fn}</p>
                <p className="text-white/40 text-xs">{desc}</p>
              </button>
            ))}
          </div>
        </details>
      </div>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-white/50 text-sm font-medium">Results</p>
            <button
              onClick={() => setResults([])}
              className="text-xs text-white/30 hover:text-red-400 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              Clear all
            </button>
          </div>
          <div className="space-y-2">
            {results.map(r => (
              <div
                key={r.id}
                className={`flex items-start justify-between gap-3 p-3 rounded-xl border transition-all ${
                  r.error
                    ? 'bg-red-500/10 border-red-500/20'
                    : 'bg-white/5 border-white/10 hover:bg-white/8'
                }`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-white/60 text-xs truncate">{r.label}</p>
                  <p className="font-mono text-xs text-white/30 truncate">{r.formula}</p>
                  {r.error ? (
                    <p className="text-red-400 text-sm mt-1">{r.error}</p>
                  ) : (
                    <p className="text-white font-mono text-xl font-bold mt-1">
                      {typeof r.result === 'number'
                        ? r.result.toLocaleString(undefined, { maximumFractionDigits: 6 })
                        : r.result}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => removeResult(r.id)}
                  className="text-white/20 hover:text-white/60 transition-colors mt-1 shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Column Stats Summary */}
      <div className="space-y-2">
        <p className="text-white/50 text-sm font-medium">Column Summary</p>
        <div className="overflow-auto rounded-xl border border-white/10">
          <table className="w-full text-xs min-w-[600px]">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                {['Column', 'Type', 'Count', 'Nulls', 'Min', 'Max', 'Mean', 'Sum'].map(h => (
                  <th key={h} className="px-3 py-2.5 text-left text-white/40 font-medium whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stats.map(s => (
                <tr key={s.name} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="px-3 py-2 text-white/80 font-medium truncate max-w-[120px]">{s.name}</td>
                  <td className="px-3 py-2">
                    <span className={`px-1.5 py-0.5 rounded text-xs font-medium ${
                      s.type === 'numeric' ? 'bg-cyan-500/20 text-cyan-300' :
                      s.type === 'string' ? 'bg-purple-500/20 text-purple-300' :
                      s.type === 'date' ? 'bg-emerald-500/20 text-emerald-300' :
                      'bg-amber-500/20 text-amber-300'
                    }`}>{s.type}</span>
                  </td>
                  <td className="px-3 py-2 font-mono text-white/70">{s.count.toLocaleString()}</td>
                  <td className="px-3 py-2 font-mono text-amber-400/70">{s.nullCount || '—'}</td>
                  <td className="px-3 py-2 font-mono text-white/60">{s.type === 'numeric' ? formatNumber(s.min as number) : (s.min ? String(s.min).slice(0, 10) : '—')}</td>
                  <td className="px-3 py-2 font-mono text-white/60">{s.type === 'numeric' ? formatNumber(s.max as number) : (s.max ? String(s.max).slice(0, 10) : '—')}</td>
                  <td className="px-3 py-2 font-mono text-cyan-300">{s.mean !== undefined ? formatNumber(s.mean) : '—'}</td>
                  <td className="px-3 py-2 font-mono text-violet-300">{s.sum !== undefined ? formatNumber(s.sum) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
