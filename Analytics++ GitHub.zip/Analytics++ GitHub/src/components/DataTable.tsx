import { useState, useMemo } from 'react';
import { Search, ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';
import { ParsedData } from '../utils/dataParser';

interface DataTableProps {
  data: ParsedData;
}

export default function DataTable({ data }: DataTableProps) {
  const [search, setSearch] = useState('');
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(0);
  const pageSize = 20;

  const filtered = useMemo(() => {
    let rows = data.rows;
    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(row =>
        Object.values(row).some(v => String(v).toLowerCase().includes(q))
      );
    }
    if (sortCol) {
      rows = [...rows].sort((a, b) => {
        const av = a[sortCol];
        const bv = b[sortCol];
        const an = Number(av), bn = Number(bv);
        let cmp: number;
        if (!isNaN(an) && !isNaN(bn)) {
          cmp = an - bn;
        } else {
          cmp = String(av).localeCompare(String(bv));
        }
        return sortDir === 'asc' ? cmp : -cmp;
      });
    }
    return rows;
  }, [data.rows, search, sortCol, sortDir]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const pageRows = filtered.slice(page * pageSize, (page + 1) * pageSize);

  const handleSort = (col: string) => {
    if (sortCol === col) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortCol(col);
      setSortDir('asc');
    }
    setPage(0);
  };

  const SortIcon = ({ col }: { col: string }) => {
    if (sortCol !== col) return <ChevronsUpDown className="w-3.5 h-3.5 opacity-40" />;
    return sortDir === 'asc'
      ? <ChevronUp className="w-3.5 h-3.5 text-violet-400" />
      : <ChevronDown className="w-3.5 h-3.5 text-violet-400" />;
  };

  return (
    <div className="flex flex-col gap-3 h-full">
      {/* Search + Info */}
      <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <input
            type="text"
            placeholder="Search all columns..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
            className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-white placeholder-white/30 text-sm focus:outline-none focus:border-violet-400/50 focus:bg-white/10 transition-all"
          />
        </div>
        <span className="text-white/40 text-xs whitespace-nowrap">
          {filtered.length.toLocaleString()} / {data.rows.length.toLocaleString()} rows
        </span>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto rounded-xl border border-white/10 bg-white/3">
        <table className="w-full text-sm min-w-max">
          <thead>
            <tr className="border-b border-white/10 bg-white/5 sticky top-0 z-10">
              <th className="px-3 py-2.5 text-left text-white/40 font-medium text-xs w-10">#</th>
              {data.headers.map(col => (
                <th
                  key={col}
                  className="px-3 py-2.5 text-left cursor-pointer select-none group"
                  onClick={() => handleSort(col)}
                >
                  <div className="flex items-center gap-1.5 text-white/70 font-medium text-xs whitespace-nowrap group-hover:text-white transition-colors">
                    <span className="truncate max-w-[120px]" title={col}>{col}</span>
                    <SortIcon col={col} />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.length === 0 ? (
              <tr>
                <td colSpan={data.headers.length + 1} className="text-center py-12 text-white/30">
                  No results found
                </td>
              </tr>
            ) : pageRows.map((row, i) => (
              <tr
                key={i}
                className="border-b border-white/5 hover:bg-white/5 transition-colors"
              >
                <td className="px-3 py-2 text-white/25 text-xs">{page * pageSize + i + 1}</td>
                {data.headers.map(col => {
                  const val = row[col];
                  const isNum = !isNaN(Number(val)) && val !== '' && val !== null;
                  return (
                    <td key={col} className="px-3 py-2 max-w-[200px]">
                      <span
                        className={`block truncate text-xs ${isNum ? 'text-cyan-300 font-mono' : 'text-white/80'}`}
                        title={String(val ?? '')}
                      >
                        {val === null || val === undefined || val === '' ? (
                          <span className="text-white/20 italic">null</span>
                        ) : String(val)}
                      </span>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="px-3 py-1.5 rounded-lg bg-white/10 text-white/70 text-xs disabled:opacity-30 hover:bg-white/20 transition-all"
          >
            ← Prev
          </button>
          <div className="flex items-center gap-1 overflow-hidden">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let p = i;
              if (totalPages > 5) {
                if (page < 3) p = i;
                else if (page > totalPages - 4) p = totalPages - 5 + i;
                else p = page - 2 + i;
              }
              return (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-7 h-7 rounded-lg text-xs transition-all ${p === page ? 'bg-violet-500 text-white' : 'text-white/50 hover:bg-white/10'}`}
                >
                  {p + 1}
                </button>
              );
            })}
          </div>
          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page === totalPages - 1}
            className="px-3 py-1.5 rounded-lg bg-white/10 text-white/70 text-xs disabled:opacity-30 hover:bg-white/20 transition-all"
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
