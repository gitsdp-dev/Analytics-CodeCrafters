import * as XLSX from 'xlsx';
import Papa from 'papaparse';

export interface ParsedData {
  headers: string[];
  rows: Record<string, any>[];
  fileName: string;
  fileType: string;
  sheets?: string[];
  activeSheet?: string;
  rowCount: number;
  colCount: number;
}

export interface ColumnStats {
  name: string;
  type: 'numeric' | 'string' | 'date' | 'boolean' | 'mixed';
  count: number;
  nullCount: number;
  uniqueCount: number;
  min?: number | string;
  max?: number | string;
  mean?: number;
  median?: number;
  stdDev?: number;
  sum?: number;
  topValues?: { value: string; count: number }[];
}

export function detectColumnType(values: any[]): 'numeric' | 'string' | 'date' | 'boolean' | 'mixed' {
  const nonNull = values.filter(v => v !== null && v !== undefined && v !== '');
  if (nonNull.length === 0) return 'string';

  const numericCount = nonNull.filter(v => !isNaN(Number(v)) && v !== '').length;
  const boolCount = nonNull.filter(v =>
    typeof v === 'boolean' || ['true', 'false', 'yes', 'no', '1', '0'].includes(String(v).toLowerCase())
  ).length;
  const dateCount = nonNull.filter(v => {
    const d = new Date(v);
    return !isNaN(d.getTime()) && isNaN(Number(v));
  }).length;

  const ratio = nonNull.length;
  if (numericCount / ratio > 0.8) return 'numeric';
  if (boolCount / ratio > 0.8) return 'boolean';
  if (dateCount / ratio > 0.7) return 'date';
  if (numericCount / ratio > 0.4) return 'mixed';
  return 'string';
}

export function computeColumnStats(headers: string[], rows: Record<string, any>[]): ColumnStats[] {
  return headers.map(col => {
    const values = rows.map(r => r[col]);
    const nonNull = values.filter(v => v !== null && v !== undefined && v !== '');
    const nullCount = values.length - nonNull.length;
    const type = detectColumnType(nonNull);
    const uniqueVals = [...new Set(nonNull.map(v => String(v)))];

    const stats: ColumnStats = {
      name: col,
      type,
      count: nonNull.length,
      nullCount,
      uniqueCount: uniqueVals.length,
    };

    if (type === 'numeric' || type === 'mixed') {
      const nums = nonNull.map(v => Number(v)).filter(n => !isNaN(n));
      if (nums.length > 0) {
        const sorted = [...nums].sort((a, b) => a - b);
        stats.min = sorted[0];
        stats.max = sorted[sorted.length - 1];
        stats.sum = nums.reduce((a, b) => a + b, 0);
        stats.mean = stats.sum / nums.length;
        stats.median = sorted.length % 2 === 0
          ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
          : sorted[Math.floor(sorted.length / 2)];
        const variance = nums.reduce((a, b) => a + Math.pow(b - stats.mean!, 2), 0) / nums.length;
        stats.stdDev = Math.sqrt(variance);
      }
    }

    if (type === 'string' || type === 'boolean') {
      const freq: Record<string, number> = {};
      nonNull.forEach(v => {
        const k = String(v);
        freq[k] = (freq[k] || 0) + 1;
      });
      stats.topValues = Object.entries(freq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([value, count]) => ({ value, count }));
    }

    if (type === 'numeric') {
      stats.min = Number(stats.min);
      stats.max = Number(stats.max);
    } else {
      const strVals = nonNull.map(v => String(v)).sort();
      stats.min = strVals[0];
      stats.max = strVals[strVals.length - 1];
    }

    return stats;
  });
}

export async function parseFile(file: File, sheetName?: string): Promise<ParsedData> {
  const ext = (file.name.split('.').pop() ?? '').toLowerCase();

  if (ext === 'csv' || ext === 'tsv' || ext === 'txt') {
    return parseCsv(file);
  } else if (['xlsx', 'xls', 'xlsm', 'xlsb', 'xlt', 'xltx', 'ods', 'accdb', 'mdb', 'dbf', 'dif', 'sylk', 'slk', 'prn', 'eth'].includes(ext)) {
    return parseXlsx(file, sheetName);
  } else if (ext === 'json') {
    return parseJson(file);
  } else {
    // Try xlsx as fallback
    try {
      return await parseXlsx(file, sheetName);
    } catch {
      throw new Error(`Unsupported file format: .${ext}`);
    }
  }
}

async function parseCsv(file: File): Promise<ParsedData> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete: (result) => {
        const headers = result.meta.fields || [];
        const rows = result.data as Record<string, any>[];
        resolve({
          headers,
          rows,
          fileName: file.name,
          fileType: file.name.split('.').pop()?.toUpperCase() || 'CSV',
          rowCount: rows.length,
          colCount: headers.length,
        });
      },
      error: reject,
    });
  });
}

async function parseXlsx(file: File, sheetName?: string): Promise<ParsedData> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
  const sheets = workbook.SheetNames;
  const activeSheet = sheetName || sheets[0];
  const worksheet = workbook.Sheets[activeSheet];

  const raw = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as any[][];
  if (!raw || raw.length === 0) {
    return { headers: [], rows: [], fileName: file.name, fileType: file.name.split('.').pop()?.toUpperCase() || 'XLSX', sheets, activeSheet, rowCount: 0, colCount: 0 };
  }

  const headers = raw[0].map((h: any) => String(h || '').trim()).filter(Boolean);
  const rows = raw.slice(1).map(row => {
    const obj: Record<string, any> = {};
    headers.forEach((h, i) => {
      obj[h] = row[i] ?? '';
    });
    return obj;
  }).filter(row => Object.values(row).some(v => v !== '' && v !== null && v !== undefined));

  return {
    headers,
    rows,
    fileName: file.name,
    fileType: file.name.split('.').pop()?.toUpperCase() || 'XLSX',
    sheets,
    activeSheet,
    rowCount: rows.length,
    colCount: headers.length,
  };
}

async function parseJson(file: File): Promise<ParsedData> {
  const text = await file.text();
  const parsed = JSON.parse(text);
  const arr = Array.isArray(parsed) ? parsed : [parsed];
  const headers = arr.length > 0 ? Object.keys(arr[0]) : [];
  return {
    headers,
    rows: arr,
    fileName: file.name,
    fileType: 'JSON',
    rowCount: arr.length,
    colCount: headers.length,
  };
}

export function formatNumber(n: number | undefined, decimals = 2): string {
  if (n === undefined || isNaN(n)) return '—';
  if (Math.abs(n) >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(2) + 'K';
  return n.toFixed(decimals);
}

export function getChartData(
  rows: Record<string, any>[],
  xCol: string,
  yCol: string,
  aggregation: 'sum' | 'avg' | 'count' | 'min' | 'max' = 'sum',
  limit = 50
): { name: string; value: number }[] {
  const grouped: Record<string, number[]> = {};
  rows.forEach(row => {
    const key = String(row[xCol] ?? 'N/A');
    const val = Number(row[yCol]);
    if (!grouped[key]) grouped[key] = [];
    if (!isNaN(val)) grouped[key].push(val);
  });

  const result = Object.entries(grouped).map(([name, vals]) => {
    let value: number;
    switch (aggregation) {
      case 'sum': value = vals.reduce((a, b) => a + b, 0); break;
      case 'avg': value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0; break;
      case 'count': value = vals.length; break;
      case 'min': value = Math.min(...vals); break;
      case 'max': value = Math.max(...vals); break;
      default: value = vals.reduce((a, b) => a + b, 0);
    }
    return { name, value };
  });

  return result.slice(0, limit);
}

export function getFrequencyData(rows: Record<string, any>[], col: string, limit = 20): { name: string; value: number }[] {
  const freq: Record<string, number> = {};
  rows.forEach(row => {
    const key = String(row[col] ?? 'N/A');
    freq[key] = (freq[key] || 0) + 1;
  });
  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([name, value]) => ({ name, value }));
}

export function getCorrelation(rows: Record<string, any>[], col1: string, col2: string): number {
  const pairs = rows.map(r => [Number(r[col1]), Number(r[col2])]).filter(([a, b]) => !isNaN(a) && !isNaN(b));
  if (pairs.length < 2) return 0;
  const n = pairs.length;
  const mean1 = pairs.reduce((s, [a]) => s + a, 0) / n;
  const mean2 = pairs.reduce((s, [, b]) => s + b, 0) / n;
  const num = pairs.reduce((s, [a, b]) => s + (a - mean1) * (b - mean2), 0);
  const den = Math.sqrt(
    pairs.reduce((s, [a]) => s + Math.pow(a - mean1, 2), 0) *
    pairs.reduce((s, [, b]) => s + Math.pow(b - mean2, 2), 0)
  );
  return den === 0 ? 0 : num / den;
}

export function getScatterData(rows: Record<string, any>[], xCol: string, yCol: string, labelCol?: string): { x: number; y: number; label?: string }[] {
  return rows
    .map(r => ({ x: Number(r[xCol]), y: Number(r[yCol]), label: labelCol ? String(r[labelCol]) : undefined }))
    .filter(p => !isNaN(p.x) && !isNaN(p.y))
    .slice(0, 500);
}

export function getHistogramData(rows: Record<string, any>[], col: string, bins = 20): { name: string; value: number }[] {
  const vals = rows.map(r => Number(r[col])).filter(v => !isNaN(v));
  if (vals.length === 0) return [];
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const binSize = (max - min) / bins;
  const counts = new Array(bins).fill(0);
  vals.forEach(v => {
    const idx = Math.min(Math.floor((v - min) / binSize), bins - 1);
    counts[idx]++;
  });
  return counts.map((count, i) => ({
    name: `${(min + i * binSize).toFixed(1)}`,
    value: count,
  }));
}
